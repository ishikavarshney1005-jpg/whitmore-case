# Whitmore Fund II — LAIM Sleeve Dashboard

Part C deliverable for the FinValley 10.0 case study.

## What this is
An interactive Streamlit dashboard built on top of the verified Part A
calculation notebook (Steps 0–9). It does **not** recompute anything — it
reads the notebook's already-verified output tables (`data/*.csv`) and
presents them for the audiences identified in Part B.

## Run it locally
```bash
pip install -r requirements.txt
streamlit run app.py
```
Opens at `http://localhost:8501`.

## Deploy it for free (so you can share a live link)
1. Create a public GitHub repo and push this whole folder (`app.py`,
   `requirements.txt`, and the `data/` folder) to it.
2. Go to https://share.streamlit.io , sign in with GitHub.
3. Click "New app", pick the repo, set the main file to `app.py`, deploy.
4. You'll get a shareable `*.streamlit.app` URL — put that in your
   submission alongside the screenshots.

## Regenerating the data if your notebook numbers change
If you go back and edit the calculation notebook, re-run it, then re-export
the tables it produces (`df_loan_book_master`, `kpi_summary`,
`hedge_effectiveness_summary`, `concentration`, `concentration_cp`,
`fx_summary`, `cds_book`, `options_summary`, `core_pnl_components`,
`oneoff_pnl_components`, `leased`, `df_sleeve_lease_cost`,
`df_revolver_util`, `df_cash_ledger`) to CSV in `data/`, and update
`data/scalars.json` with any updated single-number KPIs. The dashboard
will pick up the new numbers automatically — no code changes needed unless
you change column names.

## What each tab covers
- **Overview** — Q4 recognized P&L by component and asset class, plus the
  Orion one-off items shown separately from core/run-rate P&L.
- **Loan Book** — the deduplicated master loan book, filterable by
  obligor/servicer/coupon type.
- **Financing & Hedges** — Greystone/Ironbridge financing, the IRS/CDS/FX
  hedge-effectiveness table (color-coded by whether each hedge is working
  as designed), CDS book detail.
- **Options** — listed + OTC options recognized P&L.
- **Concentration** — both the single-name covenant test (12.5% NAV limit)
  and the separate counterparty relationship-concentration view.
- **Leased Assets** — the full lease registry and the disputed
  content-library cost treatment.
- **Cash vs. Recognized** — cash ledger filterable by asset class and
  date, plus the recognition-timing (accrual) gap metric.
- **Assumptions Log** — every judgment call from Part A in one filterable
  table, with the issue, the resolution, and the quantified impact —
  this is what "declared, not silent, assumptions" looks like to a grader.

## Verification performed before handoff
- Parsed with `ast.parse` (no syntax errors).
- Executed with Streamlit's official `AppTest` framework — 0 exceptions,
  8 tabs, 14 metrics, 12 tables all render.
- Sidebar filters exercised programmatically (asset-class multiselect) —
  reruns cleanly with 0 exceptions.
- Launched as a live server and hit with `curl` — HTTP 200,
  `/_stcore/health` returns `ok`.
- All underlying numbers were exported directly from the Part A notebook
  after that notebook was itself executed end-to-end with 0 errors — the
  dashboard is not re-deriving figures, so it can't introduce new
  calculation bugs, only presentation bugs (which the above checks rule out).
